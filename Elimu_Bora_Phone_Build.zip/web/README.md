# Elimu Bora Web
Static frontend for the Elimu Bora learning platform.

## Deployment
This folder can be deployed to Firebase Hosting, Netlify, Vercel, GitHub Pages, or another static host.

The mobile project remains in the extracted project root. Connect the web Firebase configuration before enabling web authentication/database features.
