# Elimu Bora Complete Package

Included:
- Existing Android project from Elimu Bora Working V2
- Firebase Android configuration supplied by the project owner
- A responsive web frontend in `web/`
- Learning-resource sections: notes, past papers, videos and downloads
- Payment intentionally not enabled

Before public release:
1. Build/sign the Android APK/AAB with Android Studio or CI.
2. Configure Firebase Authentication/Firestore/Storage security rules.
3. Add the Firebase Web App configuration to the web project.
4. Deploy the web folder to Firebase Hosting (or another host).
5. Test authentication, uploads, downloads and resource links on real devices.
6. Add the M-Pesa Till/payment backend only after the learning system is verified.
