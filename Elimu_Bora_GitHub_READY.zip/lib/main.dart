import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(const ElimuBoraApp());
}

class ElimuBoraApp extends StatelessWidget {
  const ElimuBoraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Elimu Bora',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.indigo,
        scaffoldBackgroundColor: const Color(0xfff7f8fc),
        inputDecorationTheme: const InputDecorationTheme(border: OutlineInputBorder()),
      ),
      home: const RootPage(),
    );
  }
}

class RootPage extends StatelessWidget {
  const RootPage({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        return snapshot.data == null ? const HomePage() : const DashboardPage();
      },
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Elimu Bora'), actions: [
        TextButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AuthPage())), child: const Text('Sign in')),
      ]),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), gradient: const LinearGradient(colors: [Color(0xff3949ab), Color(0xff5c6bc0)])),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text('Learn. Practice. Succeed.', style: TextStyle(color: Colors.white, fontSize: 28, fontWeight: FontWeight.bold)),
              SizedBox(height: 10),
              Text('Notes, past papers and video learning — all in one place.', style: TextStyle(color: Colors.white70, fontSize: 16)),
            ]),
          ),
          const SizedBox(height: 20),
          const Text('What you can access', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _feature(context, Icons.menu_book, 'Notes', 'Topic notes and revision material'),
          _feature(context, Icons.description, 'Past Papers', 'Practice examination questions'),
          _feature(context, Icons.play_circle_fill, 'Videos', 'Educational video resources'),
          _feature(context, Icons.download, 'Downloads', 'Your saved learning resources'),
          const SizedBox(height: 16),
          FilledButton.icon(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const AuthPage())), icon: const Icon(Icons.person_add), label: const Text('Create a student account')),
        ],
      ),
    );
  }

  Widget _feature(BuildContext context, IconData icon, String title, String subtitle) => Card(
    child: ListTile(leading: CircleAvatar(child: Icon(icon)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(subtitle)),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int index = 0;
  final pages = const [LibraryPage(), DownloadsPage(), ProfilePage()];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Elimu Bora'), actions: [
        IconButton(onPressed: () => showSearch(context: context, delegate: ResourceSearchDelegate()), icon: const Icon(Icons.search)),
      ]),
      body: pages[index],
      bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [
        NavigationDestination(icon: Icon(Icons.library_books_outlined), selectedIcon: Icon(Icons.library_books), label: 'Library'),
        NavigationDestination(icon: Icon(Icons.download_outlined), selectedIcon: Icon(Icons.download), label: 'Downloads'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
      ]),
    );
  }
}

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});
  static const categories = [
    ('Notes', Icons.menu_book), ('Past Papers', Icons.description), ('Videos', Icons.play_circle_fill), ('Other', Icons.folder),
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('Welcome back 👋', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
      const SizedBox(height: 6),
      const Text('Choose a resource category to start learning.'),
      const SizedBox(height: 18),
      GridView.builder(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), itemCount: categories.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.35),
        itemBuilder: (context, i) => Card(child: InkWell(borderRadius: BorderRadius.circular(12), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ResourceListPage(category: categories[i].$1))), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(categories[i].$2, size: 38), const SizedBox(height: 8), Text(categories[i].$1, style: const TextStyle(fontWeight: FontWeight.bold))])))),
      const SizedBox(height: 22),
      Card(child: ListTile(leading: const Icon(Icons.lock_open), title: const Text('Payment access'), subtitle: const Text('Coming later — M-Pesa Till integration is not enabled yet.'))),
    ]);
  }
}

class ResourceListPage extends StatelessWidget {
  final String category;
  const ResourceListPage({super.key, required this.category});

  @override
  Widget build(BuildContext context) {
    final stream = FirebaseFirestore.instance.collection('resources').where('category', isEqualTo: category).orderBy('createdAt', descending: true).snapshots();
    return Scaffold(appBar: AppBar(title: Text(category)), body: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: stream, builder: (context, snapshot) {
      if (snapshot.hasError) return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text('Could not load resources. Check your Firestore rules/indexes.\n\n${snapshot.error}', textAlign: TextAlign.center)));
      if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
      final docs = snapshot.data!.docs;
      if (docs.isEmpty) return const Center(child: Text('No resources uploaded yet.'));
      return ListView.builder(padding: const EdgeInsets.all(12), itemCount: docs.length, itemBuilder: (context, i) {
        final d = docs[i].data();
        return Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.description)), title: Text(d['title'] ?? 'Untitled'), subtitle: Text(d['subject'] ?? category), trailing: const Icon(Icons.open_in_new), onTap: () => openResource(context, d['url'] ?? '')));
      });
    }));
  }
}

Future<void> openResource(BuildContext context, String value) async {
  final uri = Uri.tryParse(value);
  if (uri == null || !(uri.scheme == 'http' || uri.scheme == 'https')) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('This resource does not have a valid web link.')));
    return;
  }
  if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Could not open the resource.')));
  }
}

class DownloadsPage extends StatelessWidget {
  const DownloadsPage({super.key});
  @override Widget build(BuildContext context) => const Center(child: Padding(padding: EdgeInsets.all(24), child: Text('Saved downloads will appear here.')));
}

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser;
    return ListView(padding: const EdgeInsets.all(20), children: [
      const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)), const SizedBox(height: 12),
      Center(child: Text(user?.email ?? '', style: const TextStyle(fontWeight: FontWeight.bold))), const SizedBox(height: 24),
      FilledButton.tonalIcon(onPressed: () => FirebaseAuth.instance.signOut(), icon: const Icon(Icons.logout), label: const Text('Sign out')),
      const SizedBox(height: 12),
      const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('Elimu Bora'), subtitle: Text('Learning resources platform'))),
    ]);
  }
}

class AuthPage extends StatefulWidget { const AuthPage({super.key}); @override State<AuthPage> createState() => _AuthPageState(); }
class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController(); final password = TextEditingController(); final name = TextEditingController();
  bool register = true, busy = false;
  String? error;
  Future<void> submit() async {
    setState(() { busy = true; error = null; });
    try {
      UserCredential cred;
      if (register) {
        cred = await FirebaseAuth.instance.createUserWithEmailAndPassword(email: email.text.trim(), password: password.text);
        await cred.user!.updateDisplayName(name.text.trim());
        await FirebaseFirestore.instance.collection('users').doc(cred.user!.uid).set({'name': name.text.trim(), 'email': email.text.trim(), 'role': 'student', 'createdAt': FieldValue.serverTimestamp()});
      } else {
        await FirebaseAuth.instance.signInWithEmailAndPassword(email: email.text.trim(), password: password.text);
      }
      if (mounted) Navigator.pop(context);
    } on FirebaseAuthException catch (e) { setState(() => error = e.message ?? e.code); }
    catch (e) { setState(() => error = e.toString()); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: Text(register ? 'Create account' : 'Sign in')), body: ListView(padding: const EdgeInsets.all(20), children: [
    Text(register ? 'Start learning with Elimu Bora' : 'Welcome back', style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)), const SizedBox(height: 20),
    if (register) ...[TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Full name')), const SizedBox(height: 12)],
    TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email')), const SizedBox(height: 12),
    TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Password')), const SizedBox(height: 16),
    if (error != null) Padding(padding: const EdgeInsets.only(bottom: 12), child: Text(error!, style: const TextStyle(color: Colors.red))),
    FilledButton(onPressed: busy ? null : submit, child: Text(busy ? 'Please wait...' : (register ? 'Create account' : 'Sign in'))),
    TextButton(onPressed: busy ? null : () => setState(() { register = !register; error = null; }), child: Text(register ? 'Already have an account? Sign in' : 'New student? Create an account')),
  ]));
}

class ResourceSearchDelegate extends SearchDelegate<String> {
  @override List<Widget>? buildActions(BuildContext context) => [IconButton(onPressed: () => query = '', icon: const Icon(Icons.clear))];
  @override Widget? buildLeading(BuildContext context) => IconButton(onPressed: () => close(context, ''), icon: const Icon(Icons.arrow_back));
  @override Widget buildResults(BuildContext context) => _results();
  @override Widget buildSuggestions(BuildContext context) => _results();
  Widget _results() => StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(stream: FirebaseFirestore.instance.collection('resources').snapshots(), builder: (context, snapshot) {
    if (!snapshot.hasData) return const Center(child: CircularProgressIndicator());
    final docs = snapshot.data!.docs.where((d) => (d.data()['title'] ?? '').toString().toLowerCase().contains(query.toLowerCase())).toList();
    return ListView.builder(itemCount: docs.length, itemBuilder: (context, i) { final d = docs[i].data(); return ListTile(title: Text(d['title'] ?? ''), subtitle: Text(d['category'] ?? ''), onTap: () => openResource(context, d['url'] ?? '')); });
  });
}
