# Elimu Bora — Phone-only build

This project includes GitHub Actions workflows that install Flutter in the cloud and build the Android APK and Flutter web version.

## On an Android phone

1. Create/sign in to a GitHub account.
2. Create a new repository, e.g. `elimu-bora`.
3. Upload the contents of this project to the repository (not the ZIP file itself).
4. Open the repository's **Actions** tab.
5. Choose **Build Elimu Bora APK** and run the workflow.
6. When it finishes, open the workflow run and download the `elimu-bora-release` artifact.
7. Extract/download the APK and install it on the phone.

No Flutter SDK needs to be installed on the phone; GitHub Actions installs Flutter on its cloud runner.

## Important
The release APK must still be tested on the real phone. Firebase Authentication/Firestore/Storage rules and any production secrets should be configured before public release.
