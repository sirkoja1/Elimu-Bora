# Elimu Bora

Starter Flutter application configured for Firebase Android project `elimu-bora-7144f` and package `com.elimubora.app`.

## Included
- Firebase Core initialization
- Firebase Auth / Firestore / Storage dependencies
- Android `google-services.json`
- Home dashboard for Notes, Past Papers, Videos and Downloads
- Payment deliberately left out for the next phase

## Build
1. Install Flutter.
2. From this folder run `flutter pub get`.
3. Run `flutter run` on Android.
4. For web, add the Firebase Web app configuration to `lib/firebase_options.dart` using FlutterFire CLI, then initialize with the generated options.
